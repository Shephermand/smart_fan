import os, sys

pid = os.fork()

if pid == 0:
    print('进入子进程')
    os.system('python3 app.py')
else:
    print('父进程退出')
    sys.exit('已退出')
