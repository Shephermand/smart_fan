from flask import Flask, request, render_template
# import RPi.GPIO as GPIO
import json
import serial

# ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
ser = serial.Serial('/dev/tty.usbmodem1434301', 9600, timeout=1)
app = Flask(__name__)
ser.flushInput()

try:
    @app.route('/')
    def hello_world():
        return render_template('resp_ctrller.html')


    @app.route('/open', methods=['POST'])
    def open_light():
        cmd = request.form['pow']
        print('这是%s档' % cmd)
        ser.write(cmd.encode('utf-8'))
        response = ser.readall()
        print('Fan: ', response.decode())
        return json.dumps(1)


except Exception as e:
    ser.close()
    print(e)

if __name__ == '__main__':  
    app.run(debug=True, host='0.0.0.0', port=11188)
