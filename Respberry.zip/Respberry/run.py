import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
# GPIO.setup(17, GPIO.OUT)

print('第一步')
time.sleep(2)

GPIO.setup(17, GPIO.OUT)
print('第二步')
time.sleep(5)
GPIO.setup(17, GPIO.IN)
print('第三步')
time.sleep(5)
GPIO.cleanup()
